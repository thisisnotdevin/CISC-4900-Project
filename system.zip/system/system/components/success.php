<!DOCTYPE html>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();



?>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NYC Checklist</title>
	<link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>
<body>
	<div class="front-page">
			<nav  style="justify-content:space-between" class="navbar">
                
                <!---logo and background from canva--->
                <div>
				    <img class="logo" src="../img/logo.png">
                </div>  
				
				<ul>
					<li><a href="../index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="help.html">Help</a></li>
					<li><a href="feedback.html">Feedback</a></li>
                    <li><a class="signin" href="login.php">Sign In</a></li>
					<div class="dropdown" data-dropdown>
                        <button id="link" class="material-symbols-outlined" data-dropdown-button>menu</button>
                        <div class="dropdown-menu">
                            <a href="../index.html">Home</a>
					        <a href="about.html">About</a>
					        <a href="help.html">Help</a>
					        <a href="feedback.html">Feedback</a>
                            <a href="login.php">Sign In</a>
                        </div>
                    </div>
				</ul>
			</nav>
			<div class="loginBox">
			

				<div>
					<img src="../img/correct.png">
					<h3>Successfully Reset your password.</h3>
					click <a href="login.php">here</a> to login
<br>
						 	  
				</div>
			
			</div> 
			
	</div>
	<script src="../script.js"></script>
</body>
</html>
